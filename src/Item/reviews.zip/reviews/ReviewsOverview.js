export default function ReviewOverview(props) {
  return (
    <>
      <div className="col-4 d-flex justify-content-center text-center">
        <div class="card" style={{ width: "18rem" }}>
          <div class="card-body">
            <h5 class="card-title">
              {props.rev.name} #{props.rev.price}
            </h5>
            <h6 class="card-subtitle mb-2 text-muted">
              Made in: {props.rev.made_in}
            </h6>
            <h6 class="card-subtitle mb-2 text-muted">
              Availability: {props.rev.available}
            </h6>
            <button onClick={() => props.delete(props.rev)}>DELETE</button>
          </div>
        </div>
      </div>
    </>
  );
}
