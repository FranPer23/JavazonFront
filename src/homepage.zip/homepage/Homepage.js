const Homepage = (props) => {
  return (
    <>
      <div className="container">
        <div className="card m-3">
          <h1 className="text-center"> HOMEPAGE</h1>
        </div>
        <div className="row">
          <div className="card col">
            <div className="card-body">
              <h5>WE ARE HERE:</h5>
            </div>
            <img
              src="https://www.toscana.info/wp-content/uploads/sites/123/mappa-firenze.jpg"
              className="card-img-top"
              alt="..."
            />
          </div>
          <div className="card col ms-3">
            <div className="card-body">
              <p className="card-text">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Homepage;
