import { Link } from "react-router-dom";

const Navbar = (prop) => {
  return (
    <>
      <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container-fluid ">
          <button
            className="navbar-toggler dropdown"
            type="button"
            data-bs-toggle="dropdown"
            data-bs-target="#navbarTogglerDemo03"
            aria-controls="navbarTogglerDemo03"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <Link className="navbar-brand" to="/">
            Homepage
          </Link>
          <div className="collapse navbar-collapse " id="navbarTogglerDemo03">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0 d-flex align-items-center">
              <li className="nav-item ms-3">
                <Link className="navbar-brand" to="/">
                  Our Products
                </Link>
              </li>
              <li className="nav-item ms-3">
                <Link className="navbar-brand" to="allemployees">
                  Our Staff
                </Link>
              </li>
              <li className="nav-item ms-3">
                <Link className="navbar-brand" to="/">
                  New Product
                </Link>
              </li>
              <li className="nav-item ms-3">
                <Link className="navbar-brand" to="employeeform">
                  New Employee
                </Link>
              </li>
            </ul>
            <form className="d-flex" role="search">
              <input
                className="form-control me-2"
                type="search"
                placeholder="Search"
                aria-label="Search"
              />
              <button className="btn btn-outline-success" type="submit">
                Search
              </button>
            </form>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Navbar;
